library(testthat)
library(eaf)

test_check("eaf")
